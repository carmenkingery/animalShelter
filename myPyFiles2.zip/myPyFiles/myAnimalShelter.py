import pymongo
from pymongo import MongoClient 
from bson.objectid import ObjectId
import json

class AnimalShelter(object):
    """ CURD operations for Animal collection in MongoDB """
    
    def __init__(self, username:str, password:str):
        self.client = MongoClient('mongodb://%s:%s@localhost:46293/AAC' % (username,password))
        self.database = self.client['AAC']
        
        
    def create(self, data:dict) -> bool:
        """ Inserts a document into a specified MongoDB database and specified collection """
        if data is not None:
            print (bool(self.database.animals.insert(data)))
        else:
            raise Exception("Nothing to save, because data parameter is empty")
            
            
    def read(self, data:dict) -> dict:
        """ Queries for documents form a specified MongoDB database and specified collection """
        if data is not None:
            found = self.database.animals.find(data,{"_id":False})
            result = {}
            if found is not None:
                #for doc in found: #iterates through curser to make printable json doc
                   # print(doc)
                return found
            else:
                raise Exception("Could not find the object you are looking for")
        else:
            raise Exception("Could not find anything because data parameter is empty")
            
        

    def update(self, data:dict, updateData:dict) -> dict:
        """ Queries for and changes documents from a specified MongoDB database and collection"""
        if data is not None:
            found = self.database.animals.find(data) #checks that the file exists
            if found is not None:
                self.database.animals.update_one(data, {"$set":updateData})
                result = self.database.animals.find(data) #finds the updated file to return to caller
                if bool(result) is True: #iterates through curser to make printable json doc
                    for doc in result:
                        updated = doc
                    return updated
                else:
                    raise Exception("Update was unsuccessful")
            else: 
                raise Exception("Could not find the object you wish to update")
        else:
            raise Exception("Nothing to update, because either data or updateData parameters are empty")
            
            
    def delete(self, data:dict) -> dict:
        """ Queries for and removes documents from a specifies MongoDB databse and collection"""
        if data is not None:
            found = self.database.animals.find(data)  #checks that the file exists
            if found is not None:
                for doc in found: #iterates through curser to make printable json doc
                    deleted = doc #saves doc to be returned to caller after deletion
                result = self.database.animals.delete_many(data)
                if bool(result) is True:
                    print("This document was successfully deleted:")
                    print(deleted)
                    print("Number of deleted items:")
                    print(result.deleted_count)
                else:
                    raise Exception("Deletion was unsuccessful")
            else:
                raise Exception("Could not find the object you wish to delete")
        else:
            raise Exception("Nothing to delete, because data parameter is empty")
            
            
            